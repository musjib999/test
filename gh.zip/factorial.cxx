#include <iostream>
using namespace std;
int factorial(int x){
	if(x > 1)
	return x * factorial(x-1);
	else
	 return 1;
}
int main(int argc, char *argv[])
{
	int num;
	
	cout << "Enter num: ";
	cin >> num;
	
	cout << endl;
	
	cout << num << "! = " << factorial(num);
		 	
 return 0;
}